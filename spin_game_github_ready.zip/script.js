
function spin() {
    const prize = Math.floor(Math.random() * 100000);
    document.getElementById("result").innerText = "You won: ৳" + prize;
}
